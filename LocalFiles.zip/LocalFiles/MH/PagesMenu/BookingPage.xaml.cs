﻿using HotelManagementSystem.Classes;
using HotelManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.PagesMenu
{
    /// <summary>
    /// Логика взаимодействия для BookingPage.xaml
    /// </summary>
    public partial class BookingPage : Page
    {
        private int _roomId;

        public BookingPage(int roomId)
        {
            InitializeComponent();
            _roomId = roomId;
            LoadRoomInfo();
            InitializeGuestFields();
        }

        private void InitializeGuestFields()
        {
            // Заполняем поля данными текущего пользователя, если они есть
            if (AuthService.CurrentUser != null)
            {
                EmailTextBox.Text = AuthService.CurrentUser.Email;
                PhoneTextBox.Text = AuthService.CurrentUser.Phone;
                FirstNameTextBox.Text = AuthService.CurrentUser.FirstName;
                LastNameTextBox.Text = AuthService.CurrentUser.LastName;
            }
        }

        private void LoadRoomInfo()
        {
            var room = AppData.db.Rooms.Find(_roomId);
            if (room != null)
            {
                RoomNumberTextBlock.Text = room.RoomNumber.ToString();
                RoomTypeTextBlock.Text = room.RoomCategories.CategoryName;
                FloorTextBlock.Text = room.Floors.FloorNumber.ToString();
                PriceTextBlock.Text = room.RoomCategories.BasePrice.ToString("C");
            }
        }

        private void BookButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка заполнения всех обязательных полей
            if (string.IsNullOrWhiteSpace(LastNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(FirstNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(PassportNumberTextBox.Text) ||
                string.IsNullOrWhiteSpace(PhoneTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля (Фамилия, Имя, Номер паспорта, Телефон)",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (CheckInDatePicker.SelectedDate == null || CheckOutDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Выберите даты заезда и выезда", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DateTime checkIn = CheckInDatePicker.SelectedDate.Value;
            DateTime checkOut = CheckOutDatePicker.SelectedDate.Value;

            if (checkIn >= checkOut)
            {
                MessageBox.Show("Дата выезда должна быть позже даты заезда", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Создаем или обновляем запись гостя
                var guest = AppData.db.Guests.FirstOrDefault(g => g.Email == EmailTextBox.Text);
                if (guest == null)
                {
                    guest = new Guests
                    {
                        FirstName = FirstNameTextBox.Text,
                        LastName = LastNameTextBox.Text,
                        MiddleName = MiddleNameTextBox.Text,
                        PassportNumber = PassportNumberTextBox.Text,
                        PassportIssueDate = PassportIssueDatePicker.SelectedDate,
                        PassportIssuedBy = PassportIssuedByTextBox.Text,
                        Email = EmailTextBox.Text,
                        Phone = PhoneTextBox.Text,
                        Address = AddressTextBox.Text,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };
                    AppData.db.Guests.Add(guest);
                    AppData.db.SaveChanges();
                }
                else
                {
                    // Обновляем данные гостя, если он уже существует
                    guest.FirstName = FirstNameTextBox.Text;
                    guest.LastName = LastNameTextBox.Text;
                    guest.MiddleName = MiddleNameTextBox.Text;
                    guest.PassportNumber = PassportNumberTextBox.Text;
                    guest.PassportIssueDate = PassportIssueDatePicker.SelectedDate;
                    guest.PassportIssuedBy = PassportIssuedByTextBox.Text;
                    guest.Phone = PhoneTextBox.Text;
                    guest.Address = AddressTextBox.Text;
                    guest.UpdatedAt = DateTime.Now;
                    AppData.db.SaveChanges();
                }

                // Создаем бронирование
                var booking = new Bookings
                {
                    RoomID = _roomId,
                    GuestID = guest.GuestID,
                    CheckInDate = checkIn,
                    CheckOutDate = checkOut,
                    Adults = 1, // Можно добавить поле для ввода количества взрослых
                    Children = 0, // Можно добавить поле для ввода количества детей
                    TotalPrice = CalculatePrice(checkIn, checkOut),
                    Status = "Confirmed",
                    CreatedBy = AuthService.CurrentUser?.UserID ?? 1, // Если пользователь не авторизован, используем ID администратора
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                AppData.db.Bookings.Add(booking);
                AppData.db.SaveChanges();

                MessageBox.Show("Бронирование успешно создано!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                NavigationService.Navigate(new MyBookingsPage());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при бронировании: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private decimal CalculatePrice(DateTime checkIn, DateTime checkOut)
        {
            var room = AppData.db.Rooms.Find(_roomId);
            if (room == null) return 0;

            int nights = (checkOut - checkIn).Days;
            return room.RoomCategories.BasePrice * nights;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
