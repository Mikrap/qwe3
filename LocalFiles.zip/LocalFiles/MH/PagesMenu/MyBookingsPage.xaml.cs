﻿using HotelManagementSystem.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.PagesMenu
{
    /// <summary>
    /// Логика взаимодействия для MyBookingsPage.xaml
    /// </summary>
    public partial class MyBookingsPage : Page
    {
        public MyBookingsPage()
        {
            InitializeComponent();
            LoadBookings();
        }

        private void LoadBookings()
        {
            if (AuthService.CurrentUser == null) return;

            var bookings = AppData.db.Bookings
                .Where(b => b.Guests.Email == AuthService.CurrentUser.Email)
                .OrderByDescending(b => b.CheckInDate)
                .ToList();

            foreach (var booking in bookings)
            {
                booking.FormattedDates = $"{booking.CheckInDate:dd.MM.yyyy} - {booking.CheckOutDate:dd.MM.yyyy}";
                booking.FormattedPrice = booking.TotalPrice.ToString("C");
            }

            BookingsListView.ItemsSource = bookings;
        }

        private void BackButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
