﻿using HotelManagementSystem.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.PagesMenu
{
    /// <summary>
    /// Логика взаимодействия для RoomListPage.xaml
    /// </summary>
    public partial class RoomListPage : Page
    {
        public RoomListPage()
        {
            InitializeComponent();
            LoadRooms();
        }

        private void LoadRooms()
        {
            var rooms = AppData.db.Rooms
                .OrderBy(r => r.RoomNumber)
                .ToList();

            RoomsListView.ItemsSource = rooms;
        }
        private void BookButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is int roomId)
            {
                NavigationService.Navigate(new BookingPage(roomId));
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
