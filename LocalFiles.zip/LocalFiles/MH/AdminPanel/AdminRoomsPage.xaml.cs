﻿using HotelManagementSystem.Classes;
using HotelManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminRoomsPage.xaml
    /// </summary>
    public partial class AdminRoomsPage : Page
    {
        public AdminRoomsPage()
        {
            InitializeComponent();
            LoadRooms();
        }

        private void LoadRooms()
        {
            RoomsDataGrid.ItemsSource = AppData.db.Rooms.ToList();
        }

        private void RoomsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = RoomsDataGrid.SelectedItem != null;
            EditButton.IsEnabled = isSelected;
            DeleteButton.IsEnabled = isSelected;
        }

        private void AddRoomButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация добавления номера
            MessageBox.Show("Функция добавления номера будет реализована позже");
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация редактирования номера
            MessageBox.Show("Функция редактирования номера будет реализована позже");
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedRoom = RoomsDataGrid.SelectedItem as Rooms;
            if (selectedRoom != null)
            {
                if (MessageBox.Show($"Вы уверены, что хотите удалить номер {selectedRoom.RoomNumber}?",
                    "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        AppData.db.Rooms.Remove(selectedRoom);
                        AppData.db.SaveChanges();
                        LoadRooms();
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
