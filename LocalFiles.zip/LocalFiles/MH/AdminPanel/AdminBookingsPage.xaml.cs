﻿using HotelManagementSystem.Classes;
using HotelManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminBookingsPage.xaml
    /// </summary>
    public partial class AdminBookingsPage : Page
    {
        public AdminBookingsPage()
        {
            InitializeComponent();
            LoadBookings();
        }

        private void LoadBookings()
        {
            var bookings = AppData.db.Bookings.ToList();
            foreach (var booking in bookings)
            {
                booking.FormattedDates = $"{booking.CheckInDate:dd.MM.yyyy} - {booking.CheckOutDate:dd.MM.yyyy}";
                BookingsDataGrid.ItemsSource = AppData.db.Bookings.ToList().Select(b => new
                {
                    b.BookingID,
                    FullName = $"{b.Guests.LastName} {b.Guests.FirstName}",
                    RoomNumber = b.Rooms.RoomNumber,
                    FormattedDates = $"{b.CheckInDate:dd.MM.yyyy} - {b.CheckOutDate:dd.MM.yyyy}",
                    b.TotalPrice,
                    b.Status
                }).ToList();
            }
            BookingsDataGrid.ItemsSource = bookings;
        }

        private void BookingsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = BookingsDataGrid.SelectedItem != null;
            EditButton.IsEnabled = isSelected;
            DeleteButton.IsEnabled = isSelected;
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация редактирования бронирования
            MessageBox.Show("Функция редактирования бронирования будет реализована позже");
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedBooking = BookingsDataGrid.SelectedItem as Bookings;
            if (selectedBooking != null)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить это бронирование?",
                    "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        AppData.db.Bookings.Remove(selectedBooking);
                        AppData.db.SaveChanges();
                        LoadBookings();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
