﻿using HotelManagementSystem.Classes;
using HotelManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminCleaningPage.xaml
    /// </summary>
    public partial class AdminCleaningPage : Page
    {
        public AdminCleaningPage()
        {
            InitializeComponent();
            LoadCleaningSchedule();
        }

        private void LoadCleaningSchedule()
        {
            CleaningDataGrid.ItemsSource = AppData.db.CleaningSchedule.ToList().Select(c => new
            {
                c.CleaningID,
                RoomNumber = c.Rooms.RoomNumber,
                StaffFullName = $"{c.Users.FirstName} {c.Users.LastName}",
                ScheduledDate = c.ScheduledDate,
                Status = c.Status
            }).ToList();
        }

        private void CleaningDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = CleaningDataGrid.SelectedItem != null;
            EditButton.IsEnabled = isSelected;
            DeleteButton.IsEnabled = isSelected;
        }

        private void AddCleaningButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация добавления задания на уборку
            MessageBox.Show("Функция добавления задания на уборку будет реализована позже");
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация редактирования задания на уборку
            MessageBox.Show("Функция редактирования задания на уборку будет реализована позже");
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedCleaning = CleaningDataGrid.SelectedItem as CleaningSchedule;
            if (selectedCleaning != null)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить это задание на уборку?",
                    "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        AppData.db.CleaningSchedule.Remove(selectedCleaning);
                        AppData.db.SaveChanges();
                        LoadCleaningSchedule();
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
