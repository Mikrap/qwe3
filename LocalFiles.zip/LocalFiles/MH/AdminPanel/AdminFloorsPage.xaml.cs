﻿using HotelManagementSystem.Classes;
using HotelManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminFloorsPage.xaml
    /// </summary>
    public partial class AdminFloorsPage : Page
    {
        public AdminFloorsPage()
        {
            InitializeComponent();
            LoadFloors();
        }

        private void LoadFloors()
        {
            FloorsDataGrid.ItemsSource = AppData.db.Floors.ToList();
        }

        private void FloorsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = FloorsDataGrid.SelectedItem != null;
            EditButton.IsEnabled = isSelected;
            DeleteButton.IsEnabled = isSelected;
        }

        private void AddFloorButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация добавления этажа
            MessageBox.Show("Функция добавления этажа будет реализована позже");
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация редактирования этажа
            MessageBox.Show("Функция редактирования этажа будет реализована позже");
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedFloor = FloorsDataGrid.SelectedItem as Floors;
            if (selectedFloor != null)
            {
                if (MessageBox.Show($"Вы уверены, что хотите удалить этаж {selectedFloor.FloorNumber}?",
                    "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        AppData.db.Floors.Remove(selectedFloor);
                        AppData.db.SaveChanges();
                        LoadFloors();
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
