﻿using HotelManagementSystem.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminGuestsPage.xaml
    /// </summary>
    public partial class AdminGuestsPage : Page
    {
        public AdminGuestsPage()
        {
            InitializeComponent();
            LoadGuests();
        }

        private void LoadGuests()
        {
            GuestsDataGrid.ItemsSource = AppData.db.Guests.ToList().Select(g => new
            {
                g.GuestID,
                FullName = $"{g.LastName} {g.FirstName} {g.MiddleName}",
                g.PassportNumber,
                g.Phone,
                g.Email
            }).ToList();
        }

        private void GuestsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = GuestsDataGrid.SelectedItem != null;
            EditButton.IsEnabled = isSelected;
            DeleteButton.IsEnabled = isSelected;
        }

        private void AddGuestButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация добавления гостя
            MessageBox.Show("Функция добавления гостя будет реализована позже");
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация редактирования гостя
            MessageBox.Show("Функция редактирования гостя будет реализована позже");
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedGuest = GuestsDataGrid.SelectedItem;
            if (selectedGuest != null)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить этого гостя?",
                    "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        dynamic guest = selectedGuest;
                        var guestToDelete = AppData.db.Guests.Find(guest.GuestID);
                        if (guestToDelete != null)
                        {
                            AppData.db.Guests.Remove(guestToDelete);
                            AppData.db.SaveChanges();
                            LoadGuests();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
