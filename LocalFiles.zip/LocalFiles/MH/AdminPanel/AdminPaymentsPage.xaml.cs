﻿using HotelManagementSystem.Classes;
using HotelManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminPaymentsPage.xaml
    /// </summary>
    public partial class AdminPaymentsPage : Page
    {
        public AdminPaymentsPage()
        {
            InitializeComponent();
            LoadPayments();
        }

        private void LoadPayments()
        {
            PaymentsDataGrid.ItemsSource = AppData.db.Payments.ToList().Select(p => new
            {
                p.PaymentID,
                p.Amount,
                PaymentDate = p.PaymentDate,
                p.PaymentMethod,
                p.Status,
                ProcessedBy = $"{p.Users.FirstName} {p.Users.LastName}"
            }).ToList();
        }

        private void PaymentsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = PaymentsDataGrid.SelectedItem != null;
            EditButton.IsEnabled = isSelected;
            DeleteButton.IsEnabled = isSelected;
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация редактирования платежа
            MessageBox.Show("Функция редактирования платежа будет реализована позже");
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedPayment = PaymentsDataGrid.SelectedItem as Payments;
            if (selectedPayment != null)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить этот платеж?",
                    "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        AppData.db.Payments.Remove(selectedPayment);
                        AppData.db.SaveChanges();
                        LoadPayments();
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
