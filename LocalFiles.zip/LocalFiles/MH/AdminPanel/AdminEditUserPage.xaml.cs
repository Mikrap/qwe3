﻿using HotelManagementSystem.Classes;
using HotelManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminEditUserPage.xaml
    /// </summary>
    public partial class AdminEditUserPage : Page
    {
        public Users CurrentUser { get; set; }
        public new string Title { get; set; }

        public AdminEditUserPage(Users user)
        {
            InitializeComponent();
            CurrentUser = user;
            Title = user.UserID == 0 ? "Добавление пользователя" : "Редактирование пользователя";
            DataContext = this;

            RoleComboBox.ItemsSource = AppData.db.UserRoles.ToList();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(CurrentUser.Username))
            {
                MessageBox.Show("Введите логин пользователя", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (CurrentUser.UserID == 0 && string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                MessageBox.Show("Введите пароль для нового пользователя", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (CurrentUser.UserID == 0)
                {
                    // Хеширование пароля перед сохранением
                    CurrentUser.Password = PasswordBox.Password;
                    AppData.db.Users.Add(CurrentUser);
                }
                else if (!string.IsNullOrWhiteSpace(PasswordBox.Password))
                {
                    // Обновление пароля, если он был изменен
                    CurrentUser.Password = PasswordBox.Password;
                }

                AppData.db.SaveChanges();
                NavigationService.GoBack();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
