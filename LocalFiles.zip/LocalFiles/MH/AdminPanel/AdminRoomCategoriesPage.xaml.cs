﻿using HotelManagementSystem.Classes;
using HotelManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminRoomCategoriesPage.xaml
    /// </summary>
    public partial class AdminRoomCategoriesPage : Page
    {
        public AdminRoomCategoriesPage()
        {
            InitializeComponent();
            LoadCategories();
        }

        private void LoadCategories()
        {
            CategoriesDataGrid.ItemsSource = AppData.db.RoomCategories.ToList();
        }

        private void CategoriesDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = CategoriesDataGrid.SelectedItem != null;
            EditButton.IsEnabled = isSelected;
            DeleteButton.IsEnabled = isSelected;
        }

        private void AddCategoryButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация добавления категории
            MessageBox.Show("Функция добавления категории будет реализована позже");
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Реализация редактирования категории
            MessageBox.Show("Функция редактирования категории будет реализована позже");
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedCategory = CategoriesDataGrid.SelectedItem as RoomCategories;
            if (selectedCategory != null)
            {
                if (MessageBox.Show($"Вы уверены, что хотите удалить категорию {selectedCategory.CategoryName}?",
                    "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        AppData.db.RoomCategories.Remove(selectedCategory);
                        AppData.db.SaveChanges();
                        LoadCategories();
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
