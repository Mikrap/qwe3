﻿using HotelManagementSystem.Classes;
using HotelManagementSystem.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelManagementSystem.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminPanelPage.xaml
    /// </summary>
    public partial class AdminPanelPage : Page
    {
        public AdminPanelPage()
        {
            InitializeComponent();
        }

        private void UsersButton_Click(object sender, RoutedEventArgs e)
        {
            AdminContentFrame.Navigate(new AdminUsersPage());
        }

        private void GuestsButton_Click(object sender, RoutedEventArgs e)
        {
            AdminContentFrame.Navigate(new AdminGuestsPage());
        }

        private void RoomsButton_Click(object sender, RoutedEventArgs e)
        {
            AdminContentFrame.Navigate(new AdminRoomsPage());
        }

        private void BookingsButton_Click(object sender, RoutedEventArgs e)
        {
            AdminContentFrame.Navigate(new AdminBookingsPage());
        }

        private void RoomCategoriesButton_Click(object sender, RoutedEventArgs e)
        {
            AdminContentFrame.Navigate(new AdminRoomCategoriesPage());
        }

        private void FloorsButton_Click(object sender, RoutedEventArgs e)
        {
            AdminContentFrame.Navigate(new AdminFloorsPage());
        }

        private void CleaningButton_Click(object sender, RoutedEventArgs e)
        {
            AdminContentFrame.Navigate(new AdminCleaningPage());
        }

        private void PaymentsButton_Click(object sender, RoutedEventArgs e)
        {
            AdminContentFrame.Navigate(new AdminPaymentsPage());
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }
    }
}
