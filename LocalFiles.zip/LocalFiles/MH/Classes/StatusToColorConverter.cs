﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace HotelManagementSystem.Classes
{
    public class StatusToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Console.WriteLine($"Converter called with value: {value}");

            if (value == null) return Brushes.Black;

            string status = value.ToString();
            Console.WriteLine($"Processing status: {status}");

            switch (status)
            {
                case "Clean":
                    return Brushes.Green;
                case "Occupied":
                    return Brushes.Red;
                case "Dirty":
                    return Brushes.Orange;
                case "AssignedForCleaning":
                    return Brushes.Blue;
                default:
                    return Brushes.Black;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}