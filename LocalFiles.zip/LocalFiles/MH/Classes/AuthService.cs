﻿using HotelManagementSystem.AdminPanel;
using HotelManagementSystem.Models;
using HotelManagementSystem.PagesMenu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace HotelManagementSystem.Classes
{
    internal class AuthService
    {
        public static Users CurrentUser { get; private set; }
        public static bool IsAdmin => CurrentUser?.RoleID == 1; // Предполагая, что 1 - ID администратора
        public static bool IsGuest => CurrentUser?.RoleID == 5; // ID гостя, как в Register

        public static bool Login(string username, string password)
        {
            try
            {
                var user = AppData.db.Users.FirstOrDefault(u => u.Username == username);
                
                if (user == null)
                {
                    MessageBox.Show("Пользователь с таким именем не найден.", "Ошибка авторизации",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                // В реальном приложении здесь должно быть хеширование пароля
                if (user.Password != password)
                {
                    MessageBox.Show("Неверный пароль.", "Ошибка авторизации",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                if (!user.IsActive.GetValueOrDefault())
                {
                    MessageBox.Show("Ваш аккаунт деактивирован. Обратитесь к администратору.",
                        "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                CurrentUser = user;
                var mainWindow = Application.Current.MainWindow as MainWindow;
                if (mainWindow != null)
                {
                    if (IsAdmin)
                    {
                        mainWindow.MainFrame.Navigate(new AdminPanelPage());
                    }
                    else
                    {
                        mainWindow.MainFrame.Navigate(new UserMenuPage());
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при авторизации: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public static bool Register(string username, string password, string email, string firstName,
                                  string lastName, string phone = null)
        {
            try
            {
                // Проверка на существующего пользователя
                if (AppData.db.Users.Any(u => u.Username == username))
                {
                    MessageBox.Show("Пользователь с таким именем уже существует.", "Ошибка регистрации",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                if (AppData.db.Users.Any(u => u.Email == email))
                {
                    MessageBox.Show("Пользователь с таким email уже существует.", "Ошибка регистрации",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                // Создание нового пользователя (по умолчанию роль "Guest")
                var newUser = new Users
                {
                    Username = username,
                    Password = password, // В реальном приложении пароль должен быть хеширован
                    FirstName = firstName,
                    LastName = lastName,
                    Email = email,
                    Phone = phone,
                    RoleID = 5, // Роль "Guest" по умолчанию
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                AppData.db.Users.Add(newUser);
                AppData.db.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при регистрации: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public static void Logout()
        {
            CurrentUser = null;
        }

        public static bool HasAccess(int requiredRoleId)
        {
            return CurrentUser?.RoleID <= requiredRoleId;
        }
    }
}
