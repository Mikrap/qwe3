﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.Classes
{
    internal class AppData
    {
        public static HotelEntities db = new HotelEntities();
    }
}
