﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для ReportsView.xaml
    /// </summary>
    public partial class ReportsView : Page
    {
        public ReportsView()
        {
            InitializeComponent();
        }

        private void OccupancyReportButton_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new DatabaseContext())
            {
                var report = context.Rooms
                    .GroupBy(r => r.RoomStatus)
                    .Select(g => new { Status = g.Key, Count = g.Count() })
                    .ToList();

                ReportDataGrid.ItemsSource = report;
            }
        }

        private void FinancialReportButton_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new DatabaseContext())
            {
                var report = context.Orders
                    .Include(o => o.Rooms)
                    .GroupBy(o => o.CheckIn.Month)
                    .Select(g => new {
                        Month = g.Key,
                        Total = g.Sum(o => DbFunctions.DiffDays(o.CheckIn, o.CheckOut) * o.Rooms.Price)
                    })
                    .ToList();

                ReportDataGrid.ItemsSource = report;
            }
        }

        private void CleaningReportButton_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new DatabaseContext())
            {
                var report = context.RoomCleanings
                    .GroupBy(c => c.Status)
                    .Select(g => new { Status = g.Key, Count = g.Count() })
                    .ToList();

                ReportDataGrid.ItemsSource = report;
            }
        }

        private void RevenueReportButton_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new DatabaseContext())
            {
                // Расчет ADR (Average Daily Rate)
                var adr = context.Orders
                    .Where(o => o.CheckIn.Year == DateTime.Now.Year && o.CheckIn.Month == DateTime.Now.Month)
                    .Average(o => o.Rooms.Price);

                // Расчет RevPAR (Revenue Per Available Room)
                var totalRooms = context.Rooms.Count();
                var totalRevenue = context.Payments.Sum(p => p.Amount);
                var revPar = totalRevenue / totalRooms;

                // Расчет загрузки номеров
                var occupiedRooms = context.Orders.Count(o => o.CheckIn <= DateTime.Now && o.CheckOut >= DateTime.Now);
                var occupancyRate = (double)occupiedRooms / totalRooms * 100;

                var report = new[]
                {
                    new {
                        Metric = "Средняя цена номера (ADR)",
                        Value = adr.ToString("C2")
                    },
                    new {
                        Metric = "Доход на номер (RevPAR)",
                        Value = revPar.ToString("C2")
                    },
                    new {
                        Metric = "Процент загрузки",
                        Value = occupancyRate.ToString("F2") + "%"
                    },
                    new {
                        Metric = "Общая выручка",
                        Value = totalRevenue.ToString("C2")
                    }
                };

                ReportDataGrid.ItemsSource = report;
            }
        }
    }
}
