﻿using ProjectDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectDemo.Views
{
    /// <summary>
    /// Логика взаимодействия для AddServiceWindow.xaml
    /// </summary>
    public partial class AddServiceWindow : Window
    {
        public AddServiceWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ServiceNameTextBox.Text) ||
                !decimal.TryParse(PriceTextBox.Text, out decimal price) ||
                string.IsNullOrWhiteSpace(DescriptionTextBox.Text)) // Добавляем проверку описания
            {
                MessageBox.Show("Заполните все поля корректно");
                return;
            }

            var service = new HotelServices
            {
                ServiceName = ServiceNameTextBox.Text,
                Description = DescriptionTextBox.Text, // Добавляем описание
                Price = price
            };

            try
            {
                using (var context = new DatabaseContext())
                {
                    context.HotelServices.Add(service);
                    context.SaveChanges();
                }

                DialogResult = true;
                Close();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                // Получаем сообщения об ошибках валидации
                var errorMessages = ex.EntityValidationErrors
                    .SelectMany(x => x.ValidationErrors)
                    .Select(x => x.ErrorMessage);

                string fullErrorMessage = string.Join("; ", errorMessages);
                MessageBox.Show($"Ошибка сохранения: {fullErrorMessage}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
